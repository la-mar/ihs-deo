Included are a sample of standard US export formats for Allocated Production data. 
	298 Comma Delimited
	298 Fixed Field
	DMP2 
	Excel Production Workbook
	EnerdeqML Production

The following is a listing of Entity Id and Entity type.

ENTITY					TYPE
142100000084MULTIWELL01	ALLOCATED
1421000026521			ALLOCATED
142100002652MULTIWELL01	ALLOCATED
242010103543			WELL
242020066266			WELL
242030007865			WELL