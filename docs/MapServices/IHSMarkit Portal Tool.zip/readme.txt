
This tool adds IHS Energy Map Services to an ArcGIS Online Portal.

To Use:

1. Copy IHSPortalToolbox.tbx to a local folder.
2. In ArcCatalog or the ArcMap Catalog window, add a connection to the local folder.
3. Expand toolbox and double click "Add IHS Map Services To Portal"
4. Input ArcGIS Portal URL. This is usually http://arcgis.com
5. Input ArcGIS Portal username and password.
6. Input IHS username and password.
7. Click OK