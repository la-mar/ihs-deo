﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Browser;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Markup;
using System.Windows.Shapes;
using System.ComponentModel;
using ESRI.ArcGIS.Client;
using System.Windows.Controls.Primitives;
using System.IO;

namespace IHSMapServicesSampleSilverlight
{
    public partial class MainPage : UserControl
    {
        //some default values.
        internal string tokenServiceURL = "https://mapservices.ihs.com/administration/token";
        internal string user = "";
        internal string pass = "";
        internal string serviceurl = "https://mapservices.ihs.com/wss/service/EMS_1_00/httpauth/US_FIELD/Field_Outlines/MapServer";
        internal string success = String.Empty;

        internal string token = string.Empty;

        public MainPage()
        {
            InitializeComponent();
            ihsUser.Text = user;
            ihsPass.Text = pass;
            ihsMapService.Text = serviceurl;
        }

        /// <summary>
        /// Add Map Service to map using user supplied IHS map service and credentials either using token based or basic authentication
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ihsButton_Click(object sender, RoutedEventArgs e)
        {
            string user = ihsUser.Text;
            string pass = ihsPass.Text;

            string mapService = ihsMapService.Text;
            //bool isToken = true;
            string proxyURL = "EMSTokenNPassword.ashx?TokenService=" + tokenServiceURL + "&UserName=" + user + "&Password=" + pass + "&ApplicationName=";
            if (rdoBasic.IsChecked.Value)
            {
                //save user and password to server to use by proxy to avoid passing in as parameters on urls
                //proxyURL = HtmlPage.Document.DocumentUri.ToString().Replace("IHSMapServicesSampleSilverlightTestPage.aspx", "EMSTokenNPassword.ashx?Username=" + user + "&Password=" + pass);
                //This code may need to change based on your environment. For example, if separating the proxy into it's own 
                //  website/virtual directory or putting it into a subdirectory.
                if (HtmlPage.Document.DocumentUri.ToString().ToLower().Contains("ihsmapservicessamplesilverlighttestpage.aspx"))
                {
                    proxyURL = HtmlPage.Document.DocumentUri.ToString().ToLower().Replace("ihsmapservicessamplesilverlighttestpage.aspx", "EMSTokenNPassword.ashx?Username=" + user + "&Password=" + pass);
                }
                else
                {
                    proxyURL = HtmlPage.Document.DocumentUri.ToString() + "EMSTokenNPassword.ashx?Username=" + user + "&Password=" + pass;
                }

                Uri uri = new Uri(proxyURL);

                //make request to proxy
                HttpWebRequest wr = (HttpWebRequest)WebRequest.Create(uri);
                wr.Method = "GET";
                wr.BeginGetResponse(new AsyncCallback(ReadPasswordCallback), wr);
            }
            else
            {

                //proxyURL = HtmlPage.Document.DocumentUri.ToString().Replace("IHSMapServicesSampleSilverlightTestPage.aspx", proxyURL);
                //This code may need to change based on your environment. For example, if separating the proxy into it's own 
                //  website/virtual directory or putting it into a subdirectory.
                if (HtmlPage.Document.DocumentUri.ToString().ToLower().Contains("ihsmapservicessamplesilverlighttestpage.aspx"))
                {
                    proxyURL = HtmlPage.Document.DocumentUri.ToString().ToLower().Replace("ihsmapservicessamplesilverlighttestpage.aspx", proxyURL);
                }
                else
                {
                    proxyURL = HtmlPage.Document.DocumentUri.ToString() + proxyURL;
                }

                Uri uri = new Uri(proxyURL);

                //make request to proxy
                HttpWebRequest wr = (HttpWebRequest)WebRequest.Create(uri);
                wr.Method = "GET";
                wr.BeginGetResponse(new AsyncCallback(ReadTokenCallback), wr);
            }
        }

        private void ReadPasswordCallback(IAsyncResult asynchronousResult)
        {
            HttpWebRequest request = (HttpWebRequest)asynchronousResult.AsyncState;
            HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(asynchronousResult);
            using (StreamReader streamReader1 = new StreamReader(response.GetResponseStream()))
            {
                string resultString = streamReader1.ReadToEnd();
                success = resultString;

                //now we can add the map layer to the map and append the token
                AddMapLayer(true);
            }
        }

        private void ReadTokenCallback(IAsyncResult asynchronousResult)
        {
            HttpWebRequest request = (HttpWebRequest)asynchronousResult.AsyncState;
            HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(asynchronousResult);
            using (StreamReader streamReader1 = new StreamReader(response.GetResponseStream()))
            {
                string resultString = streamReader1.ReadToEnd();
                token = resultString;

                //now we can add the map layer to the map and append the token
                AddMapLayer(true);
            }
        }

        private void AddMapLayer(bool useToken)
        {
            if (this.Dispatcher.CheckAccess())
            {
                ArcGISDynamicMapServiceLayer ihsMapLayer = new ArcGISDynamicMapServiceLayer();
                
                if (token != string.Empty && useToken == true)
                {
                    ihsMapLayer.Url = ihsMapService.Text; 
                    //ihsMapLayer.ProxyURL = HtmlPage.Document.DocumentUri.ToString().Replace("IHSMapServicesSampleSilverlightTestPage.aspx", "EMSProxy.ashx");
                    //This code may need to change based on your environment. For example, if separating the proxy into it's own 
                    //  website/virtual directory or putting it into a subdirectory.
                    if (HtmlPage.Document.DocumentUri.ToString().ToLower().Contains("ihsmapservicessamplesilverlighttestpage.aspx"))
                    {
                        ihsMapLayer.ProxyURL = HtmlPage.Document.DocumentUri.ToString().ToLower().Replace("ihsmapservicessamplesilverlighttestpage.aspx", "EMSProxy.ashx");
                    }
                    else
                    {
                        ihsMapLayer.ProxyURL = HtmlPage.Document.DocumentUri.ToString() + "EMSProxy.ashx";
                    }
                }
                else
                {
                    ihsMapLayer.Url = ihsMapService.Text; 
                    //ihsMapLayer.ProxyURL = HtmlPage.Document.DocumentUri.ToString().Replace("IHSMapServicesSampleSilverlightTestPage.aspx", "EMSProxy.ashx");
                    //This code may need to change based on your environment. For example, if separating the proxy into it's own 
                    //  website/virtual directory or putting it into a subdirectory.
                    if (HtmlPage.Document.DocumentUri.ToString().ToLower().Contains("ihsmapservicessamplesilverlighttestpage.aspx"))
                    {
                        ihsMapLayer.ProxyURL = HtmlPage.Document.DocumentUri.ToString().ToLower().Replace("ihsmapservicessamplesilverlighttestpage.aspx", "EMSProxy.ashx");
                    }
                    else
                    {
                        ihsMapLayer.ProxyURL = HtmlPage.Document.DocumentUri.ToString() + "EMSProxy.ashx";
                    }
                }
                ihsMapLayer.Opacity = 0.75;
                ihsMapLayer.Visible = true;
                Map.Layers.Add(ihsMapLayer);
            }
            else
                this.Dispatcher.BeginInvoke(new Action<bool>(AddMapLayer), useToken);

            
        }

        private void rdoBasic_Click(object sender, RoutedEventArgs e)
        {
            ihsMapService.Text = ihsMapService.Text.Replace("/token", "/httpauth");
        }

        private void rdoToken_Click(object sender, RoutedEventArgs e)
        {
            ihsMapService.Text = ihsMapService.Text.Replace("/httpauth", "/token");
        }
    }
}