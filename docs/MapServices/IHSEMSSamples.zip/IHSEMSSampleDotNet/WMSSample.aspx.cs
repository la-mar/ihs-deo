﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Configuration;
using System.Net;

public partial class WMSSample : System.Web.UI.Page
{
    public string cTokenHandlerUrl = String.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        Session["EMSUserName"] = "MapTesterRM2@ihs.com";
        Session["EMSPassword"] = "pwUserrm2";
        Session["EMSUseToken"] = false;
        cTokenHandlerUrl = Request.Url.AbsoluteUri.Replace("WMSSample.aspx", "proxy.ashx");
    }


}