﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Configuration;

/// <summary>
/// Summary description for ConfigClass
/// </summary>
public class ConfigClass : ConfigurationSection
{
    [ConfigurationProperty("EMSConnections", IsDefaultCollection = false)]
    [ConfigurationCollection(typeof(EMSConnections), AddItemName = "add", ClearItemsName = "clear", RemoveItemName = "remove")]
    public EMSConnections Connections
    {
        get
        {
            EMSConnections connections = (EMSConnections)base["EMSConnections"];
            return connections;
        }
    }
}

public class EMSConnections : ConfigurationElementCollection
{
    public EMSConnections()
    {
        EMSConnection cConn = CreateNewElement() as EMSConnection;
        Add(cConn);
    }

    public override ConfigurationElementCollectionType CollectionType
    {
        get
        {
            return ConfigurationElementCollectionType.AddRemoveClearMap;
        }
    }

    protected override ConfigurationElement CreateNewElement()
    {
        return new EMSConnection();
    }

    protected override object GetElementKey(ConfigurationElement element)
    {
        return ((EMSConnection)element).ConnectionName;
    }

    public EMSConnection this[int index]
    {
        get
        {
            return (EMSConnection)BaseGet(index);
        }
        set
        {
            if (BaseGet(index) != null)
            {
                BaseRemoveAt(index);
            }
            BaseAdd(index, value);
        }
    }

    new public EMSConnection this[string ConnectionName]
    {
        get
        {
            return (EMSConnection)BaseGet(ConnectionName);
        }
    }

    public int IndexOf(EMSConnection connection)
    {
        return BaseIndexOf(connection);
    }

    public void Add(EMSConnection connection)
    {
        BaseAdd(connection);
    }

    protected override void BaseAdd(ConfigurationElement element)
    {
        base.BaseAdd(element);
    }

    public void Remove(EMSConnection connection)
    {
        if (BaseIndexOf(connection) >= 0)
            BaseRemove(connection.ConnectionName);
    }

    public void RemoveAt(int index)
    {
        BaseRemoveAt(index);
    }
    public void Remove(string ConnectionName)
    {
        BaseRemove(ConnectionName);
    }
    public void Clear()
    {
        BaseClear();
    }
}

public class EMSConnection : ConfigurationElement
{
    public EMSConnection()
    {
    }

    [ConfigurationProperty("ConnectionName", IsRequired = true, IsKey = true)]
    public string ConnectionName
    {
        get
        {
            return this["ConnectionName"] as string;
        }
        set
        {
            this["ConnectionName"] = value;
        }

    }

    [ConfigurationProperty("ConnectionType", IsRequired = false, IsKey = false)]
    public string ConnectionType
    {
        get
        {
            return this["ConnectionType"] as string;
        }
        set
        {
            this["ConnectionType"] = value;
        }

    }

    [ConfigurationProperty("VisibleSubLayers", IsRequired = false)]
    public string VisibleSubLayers
    {
        get
        {
            return this["VisibleSubLayers"] as string;
        }
        set
        {
            this["VisibleSubLayers"] = value;
        }
    }

    [ConfigurationProperty("AuthorizationType", IsRequired = false)]
    public string AuthorizationType
    {
        get
        {
            return this["AuthorizationType"] as string;
        }
        set
        {
            this["AuthorizationType"] = value;
        }
    }

    [ConfigurationProperty("UserName", IsRequired = false)]
    public string UserName
    {
        get
        {
            return this["UserName"] as string;
        }
        set
        {
            this["UserName"] = value;
        }

    }

    [ConfigurationProperty("UserPassword", IsRequired = false)]
    public string UserPassword
    {
        get
        {
            return this["UserPassword"] as string;
        }
        set
        {
            this["UserPassword"] = value;
        }

    }

    [ConfigurationProperty("TokenService", IsRequired = false)]
    public string TokenService
    {
        get
        {
            return this["TokenService"] as string;
        }
        set
        {
            this["TokenService"] = value;
        }

    }

    [ConfigurationProperty("MapService", IsRequired = true)]
    public string MapService
    {
        get
        {
            return this["MapService"] as string;
        }
        set
        {
            this["MapService"] = value;
        }

    }

    [ConfigurationProperty("ImageRequestType", IsRequired = false)]
    public string ImageRequestType
    {
        get
        {
            return this["ImageRequestType"] as string;
        }
        set
        {
            this["ImageRequestType"] = value;
        }

    }

    [ConfigurationProperty("ApplicationName", IsRequired = false, DefaultValue = "___ENERDEQ___")]
    public string ApplicationName
    {
        get
        {
            return this["ApplicationName"] as string;
        }
        set
        {
            this["ApplicationName"] = value;
        }

    }

    [ConfigurationProperty("MapServiceType", IsRequired = false, DefaultValue = "Tiled")]
    public string MapServiceType
    {
        get
        {
            return this["MapServiceType"] as string;
        }
        set
        {
            this["MapServiceType"] = value;
        }

    }
}