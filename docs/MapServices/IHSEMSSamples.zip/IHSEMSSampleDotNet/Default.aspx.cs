﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Configuration;

public partial class _Default : System.Web.UI.Page, System.Web.UI.ICallbackEventHandler
{
    public string cTokenService = String.Empty;
    public string cUserName = String.Empty;
    public string cUserPass = String.Empty;

    public string cMapService = String.Empty;
    public string cAppName = String.Empty;
    public string cImageType = String.Empty;

    public string cMapServiceType = String.Empty;

    public string cConnectionSelect = String.Empty;

    public string cTokenHandlerUrl = String.Empty;
    public string cEntitlementHandlerUrl = String.Empty;

    public string cVisibleSubLayers = String.Empty;
    public string cConnectionType = String.Empty;
    public bool cUseToken = true;

    public string cAuthType = String.Empty;

    /// <summary>
    /// On Page Load, creates connection list from web.config populates first connection and registers callback.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        //create config section if missing
        CreateConfig();

        ReadConfig();

        //*******************************************************************************
        //This code may need to change based on your environment. For example, if separating the proxy into it's own 
        //  website/virtual directory or putting it into a subdirectory.
        if (Request.Url.AbsoluteUri.ToLower().Contains("default.aspx"))
        {
            cTokenHandlerUrl = Request.Url.AbsoluteUri.ToLower().Replace("default.aspx", "emsTokenGenerator.ashx");
            cEntitlementHandlerUrl = Request.Url.AbsoluteUri.ToLower().Replace("default.aspx", "emsEntitlements.ashx");
        }
        else
        {
            cTokenHandlerUrl = Request.Url + "emsTokenGenerator.ashx";
            cEntitlementHandlerUrl = Request.Url + "emsEntitlements.ashx";
        }
        //*******************************************************************************

        //read default config variables from web.config
        ConfigClass config = Session["EMSConnections"] as ConfigClass;

        foreach (EMSConnection conn in config.Connections)
        {
            if (conn.ConnectionName != String.Empty)
            {
                if (conn.ConnectionType == "NONE")
                {
                    cConnectionSelect += "<option style=\"font-weight:bold;color:blue;\" value=\"" + conn.ConnectionName + "\">" + conn.ConnectionName + "</option>";
                }
                else
                {
                    cConnectionSelect += "<option value=\"" + conn.ConnectionName + "\">" + conn.ConnectionName + "</option>";
                }
            }
        }

        cUserName = config.Connections[1].UserName;
        cUserPass = config.Connections[1].UserPassword;
        cTokenService = config.Connections[1].TokenService;
        cMapService = config.Connections[1].MapService;
        cImageType = config.Connections[1].ImageRequestType.ToUpper();
        cAppName = config.Connections[1].ApplicationName;
        cMapServiceType = config.Connections[1].MapServiceType;
        cVisibleSubLayers = config.Connections[1].VisibleSubLayers;
        cConnectionType = config.Connections[1].ConnectionType;

        if (cConnectionType == String.Empty)
        {
            cConnectionType = "CSM";
        }

        if (config.Connections[1].AuthorizationType != null)
        {
            if (config.Connections[1].AuthorizationType == "basic")
            {
                cUseToken = false;
            }
            else
            {
                cUseToken = true;
            }
        }

        //save to session vars
        Session["EMSUserName"] = cUserName;
        Session["EMSPassword"] = cUserPass;
        Session["EMSTokenService"] = cTokenService;
        Session["EMSMapService"] = cMapService;
        Session["EMSImageRequestType"] = cImageType.ToUpper();
        Session["EMSApplicationName"] = cAppName;
        Session["EMSMapServiceType"] = cMapServiceType;
        Session["EMSVisibleSubLayers"] = cVisibleSubLayers;
        Session["EMSUseToken"] = cUseToken;
        Session["ConnectionType"] = cConnectionType;

        //Setup Callbacks
        ClientScriptManager cm = Page.ClientScript;
        String cbReference = cm.GetCallbackEventReference(this, "arg",
            "_map.ReceiveServerData", "");
        String callbackScript = "function _updateEMSProperties(arg, context) {" +
            cbReference + "; }";
        cm.RegisterClientScriptBlock(this.GetType(),
            "UpdateEMSProperties", callbackScript, true);
    }

    /// <summary>
    /// Reads Connections from web.config
    /// </summary>
    private void ReadConfig()
    {
        //try
       // {
            ConfigClass config = ConfigurationManager.GetSection("EMSConnectionsSection") as ConfigClass;
            if (config != null)
            {
                //store the config in the session
                Session["EMSConnections"] = config;
            }
        //}
        //catch (ConfigurationErrorsException err)
        //{
            //tis not good
        //}
    }

    /// <summary>
    /// Adds Configuration to Configurations List
    /// </summary>
    /// <param name="connectionName"></param>
    /// <param name="connectionType"></param>
    /// <param name="applicationName"></param>
    /// <param name="imageType"></param>
    /// <param name="mapService"></param>
    /// <param name="mapServiceType"></param>
    /// <param name="tokenService"></param>
    /// <param name="userName"></param>
    /// <param name="password"></param>
    /// <param name="visibleLayers"></param>
    /// <param name="authorizationType"></param>
    /// <returns></returns>
    public bool AddToConfig(string connectionName, string connectionType, string applicationName, string imageType, string mapService, string mapServiceType,
        string tokenService, string userName, string password, string visibleLayers, string authorizationType)
    {
        try
        {
            ConfigClass conn = new ConfigClass();
            EMSConnection con1 = new EMSConnection();

            con1.ApplicationName = applicationName;
            con1.ConnectionName = connectionName;
            con1.ConnectionType = connectionType;
            con1.ImageRequestType = imageType.ToUpper();
            con1.MapService = mapService;
            con1.MapServiceType = mapServiceType;
            con1.TokenService = tokenService;
            con1.UserName = userName;
            con1.UserPassword = password;
            con1.VisibleSubLayers = visibleLayers;
            con1.AuthorizationType = authorizationType;
            conn.Connections.Add(con1);

            Configuration config = WebConfigurationManager.OpenWebConfiguration("~");
            config.Sections.Add("EMSConnectionsSection", conn);
            conn.SectionInformation.ForceSave = true;

            config.Save(ConfigurationSaveMode.Modified);
            return true;
        }
        catch (ConfigurationErrorsException err)
        {
            return false;
        }
    }
    /// <summary>
    /// If no configurations exist, this creates a single dummy configuration
    /// </summary>
    private void CreateConfig()
    {
        try
        {
            ConfigClass conn = new ConfigClass();

            //adds a sample (not real values) to config file
            EMSConnection con1 = new EMSConnection();
            con1.ApplicationName = "___ENERDEQ___";
            con1.ConnectionName = "Con1";
            con1.ConnectionType = "CSM"; //"AGS" for arcGIS Server, "NONE" for none
            con1.ImageRequestType = "png8".ToUpper();
            con1.MapService = "httpsafsdfsfsf/sdfsf";
            con1.MapServiceType = "Tiled";
            con1.TokenService = "asdfsfs";
            con1.UserName = "user1";
            con1.UserPassword = "pass1";
            con1.VisibleSubLayers = "1";
            con1.AuthorizationType = "token";
            conn.Connections.Add(con1);

            Configuration config = WebConfigurationManager.OpenWebConfiguration("~");
            if (config.Sections["EMSConnectionsSection"] == null)
            {
                config.Sections.Add("EMSConnectionsSection", conn);
            }

            conn.SectionInformation.ForceSave = true;

            config.Save(ConfigurationSaveMode.Modified);
        }
        catch (ConfigurationErrorsException err)
        {
            //well didn't work too well.
        }
    }

    /// <summary>
    /// Raise Callback event and handle client information, save to session for later use
    /// </summary>
    /// <param name="eventArgument"></param>
    public void RaiseCallbackEvent(String eventArgument)
    {
        //parse data
        Hashtable values = new Hashtable();
        string[] args = eventArgument.Split('&');
        for (int i = 0; i < args.Length; i++)
        {
            string[] vals = args[i].Split('=');
            values.Add(vals[0], vals[1]);
        }

        ConfigClass config = Session["EMSConnections"] as ConfigClass;

        if (values["ConfigSelectName"] != null)
        {
            foreach (EMSConnection conn in config.Connections)
            {
                if (conn.ConnectionName == values["ConfigSelectName"].ToString())
                {
                    Session["EMSUserName"] = conn.UserName;
                    Session["EMSPassword"] = conn.UserPassword;
                    Session["EMSTokenService"] = conn.TokenService;
                    Session["EMSMapService"] = conn.MapService;
                    Session["EMSApplicationName"] = conn.ApplicationName;
                    Session["EMSMapServiceType"] = conn.MapServiceType;
                    Session["EMSVisibleSubLayers"] = conn.VisibleSubLayers;
                    Session["EMSImageRequestType"] = conn.ImageRequestType.ToUpper();
                    if (conn.AuthorizationType == "basic")
                    {
                        Session["EMSUseToken"] = false;
                    }
                    else
                    {
                        Session["EMSUseToken"] = true;
                    }
                    Session["EMSUpdate"] = false;
                    if (conn.ConnectionType == string.Empty)
                    {
                        Session["ConnectionType"] = "CSM";
                    }
                    else
                    {
                        Session["ConnectionType"] = conn.ConnectionType;
                    }
                }
            }

        }
        else
        {
            //update session vars
            Session["EMSUserName"] = values["EMSUserName"];
            Session["EMSPassword"] = values["EMSPassword"];
            Session["EMSTokenService"] = values["EMSTokenService"];
            Session["EMSMapService"] = values["EMSMapService"];
            Session["EMSApplicationName"] = values["EMSApplicationName"];
            Session["EMSMapServiceType"] = values["EMSMapServiceType"];
            Session["EMSVisibleSubLayers"] = values["EMSVisibleSubLayers"];
            Session["EMSImageRequestType"] = values["EMSImageRequestType"];
            Session["EMSUpdate"] = true;
            Session["EMSUseToken"] = bool.Parse(values["EMSUseToken"].ToString());
            if (values["ConnectionType"].ToString() == String.Empty)
            {
                Session["ConnectionType"] = "CSM";
            }
            else
            {
                Session["ConnectionType"] = values["ConnectionType"];
            }
        }
    }

    /// <summary>
    /// Returns Callback result
    /// </summary>
    /// <returns></returns>
    public string GetCallbackResult()
    {
        //return updated values
        string retVal = Session["EMSUserName"] + "," + Session["EMSPassword"] + "," + Session["EMSTokenService"] + "," +
            Session["EMSMapService"] + "," + Session["EMSApplicationName"] + "," + Session["EMSMapServiceType"] + "," + Session["EMSUpdate"].ToString() +
            "," + Session["EMSVisibleSubLayers"].ToString().Replace(",", "|") + "," + Session["EMSUseToken"] + "," + Session["ConnectionType"] + "," + Session["EMSImageRequestType"];

        return retVal;
    }
    /// <summary>
    /// Sends client update
    /// </summary>
    public void SendClientUpdate()
    {
        string javaScript =
            "<script language=JavaScript>\n" +
            "alert('Yo Yo client-side');\n" +
             "</script>";
        Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "clientScript", javaScript, false);
    }
}