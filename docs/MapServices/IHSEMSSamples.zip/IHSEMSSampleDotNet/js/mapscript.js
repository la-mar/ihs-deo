﻿
/*
Title: mapscript.js
Author: David Jones, IHS

This file provides all client logic for the IHSEMSSampleDotNet application.  Users are free to use, modify or change code herein.

*/
dojo.require("dijit.layout.BorderContainer");
dojo.require("dijit.layout.TabContainer");
dojo.require("dijit.layout.ContentPane");
dojo.require("dijit.TitlePane");
dojo.require("dijit.TooltipDialog");
dojo.require("dijit.form.TextBox");
dojo.require("dijit.form.Button");
dojo.require("dijit.form.ComboBox");
dojo.require("dijit.form.CheckBox");
dojo.require("dijit.form.Select");
dojo.require("dijit.form.FilteringSelect");
dojo.require("dijit.Dialog");
dojo.require("dijit.MenuBar");
dojo.require("dijit.MenuBarItem");
dojo.require("dijit.PopupMenuBarItem");
dojo.require("dijit.Menu");
dojo.require("dijit.MenuItem");
dojo.require("dijit.PopupMenuItem");
dojo.require("dijit.Toolbar");
dojo.require("dojox.layout.FloatingPane");

//The ESRI map control must use a proxy to properly work with the secure IHS EMS service end points.
esri.config.defaults.io.proxyUrl = "proxy.ashx";
esri.config.defaults.io.alwaysUseProxy = true;

var IHS = {};
IHS.GIS = {};
IHS.GIS.Mapping = {};
IHS.GIS.Mapping.EMS = function () {
    //internal

    var _map;
    var _token;
    var _tokenErrorDlg;
    var _statusDlg;
    var _entitlementDlg;
    var _entitlementDlg2;
    var _entitlementSource;
    var _entitlementObj;

    //Initialze ESRI map control, add basemap and request token from IHS Administration Service.
    var _init = function () {

        //token error dialog
        _tokenErrorDlg = new dijit.Dialog({
            title: "Token Generation Error",
            style: "width: 450px"
        });

        //map service error dialog
        _statusDlg = new dijit.Dialog({
            title: "Map Service Error",
            style: "width: 450px"
        });

        _entitlementDlg = dijit.byId("entitlementDlg");

        _entitlementDlg2 = new dijit.Dialog({
            title: "Security Manager Entitlements Source",
            style: "width: 850px; height:600px;"
        });

        //set service type
        if (_defaultProtectedServiceType == "Dynamic") {
            dijit.byId("cMSTypeDynamic").attr('checked', true);
        } else {
            dijit.byId("cMSTypeTiled").attr('checked', true);
        }
        //set security type
        if (_useToken === true) {
            dijit.byId("cMSAuthToken").attr('checked', true);
            _setAuthType("token");
        } else {
            dijit.byId("cMSAuthBasic").attr('checked', true);
            _setAuthType("basic");
        }
        //create the map
        _map = new esri.Map("map");

        dojo.connect(_map, "onLayerAddResult", _onLayerAddResult);

        //Add the world street map layer to the map. View the ArcGIS Online site for services http://arcgisonline/home/search.html?t=content&f=typekeywords:service    
        var basemap = new esri.layers.ArcGISTiledMapServiceLayer("http://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer");
        _map.addLayer(basemap);

        //wire map resize
        dojo.connect(_map, 'onLoad', function (theMap) {
            //resize the map when the browser resizes
            dojo.connect(dijit.byId('map'), 'resize', _map, _map.resize);
        });

        dojo.connect(window, "onresize", function () {
            var vbox = dojo.window.getBox();
            dojo.style(dojo.byId("mapContainer"), { height: vbox.h + "px" });
            dojo.style(dojo.byId("mapContainer"), { width: vbox.w + "px" });
            _map.resize();
        });

        var vbox = dojo.window.getBox();
        dojo.style(dojo.byId("mapContainer"), { height: vbox.h + "px" });
        dojo.style(dojo.byId("mapContainer"), { width: vbox.w + "px" });
        _map.resize();

        _setConnType(_connType);

        _setMapServiceType(_defaultProtectedServiceType);

        _setImageType(_imageType);

        //request token and authenticate to add dynamic IHS protected service
        if (_connType == "CSM") {
            if (_useToken === true) {
                _requestToken();
            } else {
                _addProtectedService();
            }
        } else if (_connType == "AGS") {
            _addProtectedService();
        } else {
            document.getElementById("allArea").style.display = "none";
        }

    };

    //handle on layer add result
    var _onLayerAddResult = function (layer, error) {
        if (error != null) {
            _statusDlg.attr("content", "Failed to add map service to map:<br/>" + error.message);
            document.getElementById("mapStatusUpdate").innerHTML = "Failed to add map service for: " + _getSelectValue();
            _statusDlg.show();
        } else {
            if (layer.id == "EMSMapLayer") {
                document.getElementById("mapStatusUpdate").innerHTML = "Map Service added for: " + _getSelectValue();
            }
        }
    };

    //uses geometry service to project point to Lat/Long (user clicks map)
    var _projectPoint = function (evt) {
        _map.graphics.clear();

        var point = evt.mapPoint;
        var symbol = new esri.symbol.SimpleMarkerSymbol().setStyle(esri.symbol.SimpleMarkerSymbol.STYLE_DIAMOND);
        var graphic = new esri.Graphic(point, symbol);
        var outSR = new esri.SpatialReference({ wkid: 4326 });

        _map.graphics.add(graphic);

        gsvc.project([point], outSR, function (projectedPoints) {
            pt = projectedPoints[0];
            graphic.setInfoTemplate(new esri.InfoTemplate("Coordinates",
            "<p>&nbsp;X: " + pt.x +
            "<br/>&nbsp;Y: " + pt.y +
            "</p>" +
            "<div id='latlong'></div>"));
            _map.infoWindow
            .setTitle(graphic.getTitle())
            .setContent(graphic.getContent())
            .show(evt.screenPoint, _map.getInfoWindowAnchor(evt.screenPoint));
        });
    };

    //Adds the IHS EMS protected service to the map.  The created map service layer is exactly the same as if one was using a ESRI ArcGIS Server rest point directly.
    var _addProtectedService = function () {
        if (!_token && _useToken === true && _connType == "CSM") {
            _tokenErrorDlg.attr("content", "The token service returned a blank or null token.  Map service cannot be added.<br/>");
            _tokenErrorDlg.show();
            document.getElementById("mapStatusUpdate").innerHTML = "Unable to generate token for: " + _getSelectValue();
            return;
        }

        //create IHS EMS map service URL with token appended
        var serviceUrlWithToken = _defaultProtectedServiceUrl;
        if (_useToken === true && _connType == "CSM") {
            serviceUrlWithToken = serviceUrlWithToken + "?token=" + escape(_token);
        }
        //Add service to map
        var mapLayer = null;
        document.getElementById("mapStatusUpdate").innerHTML = "<img src='progressAnime.gif' title='Attempting to add service to map...'/>&nbsp;Attempting to add service to map...";
        if (_defaultProtectedServiceType == "Dynamic") {
            var imageParameters = new esri.layers.ImageParameters();
            imageParameters.format = _imageType;
            var mapLayer = new esri.layers.ArcGISDynamicMapServiceLayer(serviceUrlWithToken, { "imageParameters": imageParameters, "id": "EMSMapLayer" });
            var vislayers = dijit.byId("cVisibleSubLayers").attr("value");
            if (vislayers != "") {
                var visible = vislayers.split(",");
                for (var k = 0; k < visible.length; k++) {
                    visible[k] = parseInt(visible[k]);
                }
                mapLayer.setVisibleLayers(visible);
            } else {
                var visible = [];
            }
            _map.addLayer(mapLayer);
        } else {
            //tiled
            var mapLayer = new esri.layers.ArcGISTiledMapServiceLayer(serviceUrlWithToken, { "id": "EMSMapLayer" });
            _map.addLayer(mapLayer);
        }

        gsvc = new esri.tasks.GeometryService("https://mapservices.ihs.com/wss/service/EMS_1_00/token/Utility/Geometry/GeometryServer?token=" + escape(_token));
        dojo.connect(_map, "onClick", _projectPoint);

    };

    //Show entitlements
    var _showEntitlements = function (entitlements) {
        entitlementSource = entitlements;
        dojo.byId("entitlementUserId").innerHTML = dijit.byId("cUserName").attr("value");

        _entitlementDlg.show();
    };
    //display entiltment dialog
    var _getEntitlementsSource = function () {
        _entitlementDlg2.attr("content", "<div style='overflow:auto;width:100%;height:100%'>" + entitlementSource + "</div>");
        _entitlementDlg2.show();
    };

    //get entitlements
    var _getEntitlements = function () {
        dojo.xhrGet({
            url: _entitlementURL,
            load: function (response, ioargs) {
                if (!response) {
                    _tokenErrorDlg.attr("content", "Unknown Error from Entitlement Handler");
                    document.getElementById("mapStatusUpdate").innerHTML = "Unable to show entitlements for: " + _getSelectValue();
                    _tokenErrorDlg.show();
                    return;
                }
                if (response != null) {
                    //Worked, add protected service 
                    _showEntitlements(response);
                } else {
                    _tokenErrorDlg.attr("content", "The entitlement handler returned a blank or null token.  Map service cannot be added.<br/>");
                    _tokenErrorDlg.show();
                    document.getElementById("mapStatusUpdate").innerHTML = "Unable to generate a handler JSON string for: " + _getSelectValue();
                }
            },
            error: function (error) {
                _tokenErrorDlg.attr("content", "The entitlement handler returned the following error from the token service:<br/><br/>HTTP Error Code: " + error.status + "<br/>Error Message: " + error.responseText + "<br/>");
                _tokenErrorDlg.show();
                document.getElementById("mapStatusUpdate").innerHTML = "Unable to generate token for: " + _getSelectValue();
            }
        });
    };

    //Requests Token using local IHS EMS token generation page (that communicates with EMS directly)
    var _requestToken = function () {
        dojo.xhrGet({
            url: _proxyURL,
            load: function (response, ioargs) {
                if (!response) {
                    _tokenErrorDlg.attr("content", "Unknown Error from token generation service");
                    document.getElementById("mapStatusUpdate").innerHTML = "Unable to generate token for: " + _getSelectValue();
                    _tokenErrorDlg.show();
                    return;
                }
                _token = response;
                if (_token != null) {
                    dijit.byId('cToken').attr('value', _token);
                    //Worked, add protected service 
                    _addProtectedService();
                    //We've got a good token, now call the request token function again in 29 min so it doesn't expire on a user
                    window.setInterval(_requestToken, 1740000); //1740000 = 29 minutes
                } else {
                    _tokenErrorDlg.attr("content", "The token service returned a blank or null token.  Map service cannot be added.<br/>");
                    _tokenErrorDlg.show();
                    document.getElementById("mapStatusUpdate").innerHTML = "Unable to generate token for: " + _getSelectValue();
                }
            },
            error: function (error) {
                _tokenErrorDlg.attr("content", "The token handler returned the following error from the token service:<br/><br/>HTTP Error Code: " + error.status + "<br/>Error Message: " + error.responseText + "<br/>");
                _tokenErrorDlg.show();
                document.getElementById("mapStatusUpdate").innerHTML = "Unable to generate token for: " + _getSelectValue();
            }
        });
    };

    //updates IHS EMS Service Parameters
    var _updateEMSServiceParameters = function (sendToServer, updateConfig, saveAsNewConfig, saveAsNewName) {
        //get parameters to send to server
        var tsURL = dijit.byId("cTokenService").attr("value");
        var tsU = dijit.byId("cUserName").attr("value");
        var tsP = dijit.byId("cUserPassword").attr("value");
        var tsMS = dijit.byId("cServiceUrl").attr("value");
        var tsMSType = dojo.query('[name=cMSType]').filter(function (radio) { return radio.checked; }).attr('value')[0];
        var tsI = dojo.query('[name=cImageType]').filter(function (radio) { return radio.checked; }).attr('value')[0];
        var subl = dijit.byId("cVisibleSubLayers").attr("value");

        var tsAN = dijit.byId("cAppName").attr("value");

        var tConnType = dojo.query('[name=cMSConnType]').filter(function (radio) { return radio.checked; }).attr('value')[0];



        var updateValues = "EMSTokenService=" + tsURL + "&EMSUserName=" + tsU + "&EMSPassword=" + tsP + "&EMSMapService=" + tsMS +
                "&EMSApplicationName=" + tsAN + "&EMSImageRequestType=" + tsI + "&EMSMapServiceType=" + tsMSType + "&EMSUseToken=" + _useToken +
                "&EMSVisibleSubLayers=" + subl + "&ConnectionType=" + tConnType;
        if (updateConfig && updateConfig === true) {
            updateValues = updateValues + "&Save=true";
        }
        if (saveAsNewConfig && saveAsNewConfig === true) {
            updateValues = updateValues + "&SaveAsNew=true&SaveAsNewName=" + saveAsNewName;
        }

        _defaultProtectedServiceUrl = tsMS;
        _defaultProtectedServiceType = tsMSType
        //only create a server callback if needed
        if (sendToServer != false) {
            _updateEMSProperties(updateValues);
        }
    };

    //Save configuraton (NOT WORKING)
    var _saveConfiguration = function (overwrite, name) {
        if (!overwrite && name == null) {
            //save as, get new name from user
            dijit.byId("saveAsDialog").attr("title", "Save Connection As...");
            dijit.byId("saveAsDialog").show();
        } else if (!overwrite && name != null) {
            //check if name is already in list, if so inform user and don't proceed, else proceed
            var found = false;
            var sels = document.getElementById("cConnSel");
            //loop through and find it
            for (i = 0; i < sels.length; i++) {
                txt = sels.options[i].text;
                if (txt == name) {
                    found = true;
                }
            }
            if (!found) {
                dijit.byId("saveAsDialog").hide();
                //_updateEMSServiceParameters(true, true, false, name);
            } else {
                //let user know its already used

            }
        }
        //save and overwrite
        //_updateEMSServiceParameters(true, false, true);
    };

    //Update client from server
    var _receiveServerData = function (arg, context) {
        document.getElementById("mapStatusUpdate").innerHTML = "<img src='progressAnime.gif' title='Updating Map...'/>";

        //split arg and updated the values
        var vals = arg.split(',');

        if (vals[9] == "NONE") {
            document.getElementById("mapStatusUpdate").innerHTML = "";
            document.getElementById("allArea").style.display = "none";
            _clearMap();
            return;
        } else {
            document.getElementById("allArea").style.display = "inline";
        }

        dijit.byId('cUserName').attr('value', vals[0]);
        dijit.byId('cUserPassword').attr('value', vals[1]);
        dijit.byId('cTokenService').attr('value', vals[2]);
        dijit.byId('cServiceUrl').attr('value', vals[3]);
        dijit.byId('cAppName').attr('value', vals[4]);

        if (vals[5] == "Dynamic") {
            dijit.byId("cMSTypeDynamic").attr('checked', true);
            _setMapServiceType("Dynamic");
        } else {
            dijit.byId("cMSTypeTiled").attr('checked', true);
            _setMapServiceType("Tiled");
        }
        var visLayers = vals[7].replace(/\|/g, ",")
        dijit.byId("cVisibleSubLayers").attr("value", visLayers);

        if (vals[8] == "True") {
            _useToken = true;
            dijit.byId("cMSAuthToken").attr('checked', true);
            _setAuthType("token");
        } else {
            _useToken = false;
            dijit.byId("cMSAuthBasic").attr('checked', true);
            _setAuthType("basic");
        }

        //conn
        if (vals[9] == "CSM") {
            _connType = "CSM";
            dijit.byId("cMSConnTypeCSM").attr('checked', true);
        } else if (vals[9] == "AGS") {
            _connType = "AGS";
            dijit.byId("cMSConnTypeAGS").attr('checked', true);
        }

        //imageType
        if (vals[10] == "PNG8") {
            _imageType = "PNG8";
            dijit.byId("cImageTypePNG8").attr('checked', true);
        } else if (vals[10] == "PNG32") {
            _imageType = "PNG32";
            dijit.byId("cImageTypePNG32").attr('checked', true);
        }

        if (vals[6] == "False") {
            _updateEMSServiceParameters(false);
        } else {
            _updateEMSServiceParameters(false);
        }
        _updateMap();
    };

    //Clear Map
    var _clearMap = function () {
        var cLayer = null;
        cLayer = _map.getLayer("EMSMapLayer");
        if (cLayer) {
            _map.removeLayer(cLayer);
        }
    };
    //Update Map
    var _updateMap = function () {
        _clearMap();
        dijit.byId('cToken').attr('value', "");
        if (_useToken === true && _connType == "CSM") {
            _requestToken();
        } else {
            _addProtectedService();
        }
    };
    //Get selected Connection
    var _getSelectValue = function () {
        var selector = dojo.byId("cConnSel")
        var index = selector.selectedIndex;
        var selectVal = selector.options[index].text;
        return selectVal;
    };
    // Handle Connection Change Event
    var _onSelectChange = function () {
        var val = "ConfigSelectName=" + _getSelectValue();
        _updateEMSProperties(val);
    };
    //set authorization type
    var _setAuthType = function (type) {
        if (type == "basic") {
            dojo.byId("cToken").disabled = true;
            dojo.byId("msTokenId").disabled = true;
            dojo.byId("cTokenService").disabled = true;
            dijit.byId('cServiceUrl').attr('value', dijit.byId('cServiceUrl').attr('value').replace('/token/', '/httpauth/'));
            _useToken = false;
        } else {
            dojo.byId("cToken").disabled = false;
            dojo.byId("msTokenId").disabled = false;
            dojo.byId("cTokenService").disabled = false;
            dijit.byId('cServiceUrl').attr('value', dijit.byId('cServiceUrl').attr('value').replace('/httpauth/', '/token/'));
            _useToken = true;
        }
    };
    //Set Connection Type
    var _setConnType = function (type) {
        if (type == "CSM") {
            _connType = "CSM";
            document.getElementById("emsArea1").style.display = "block";
            document.getElementById("emsArea2").style.display = "block";
            document.getElementById("emsArea3").style.display = "inline-block";
            //dojo.byId('emsArea1').style("visibility", "visible");
            dojo.byId("cMSAuthToken").disabled = false;
            dojo.byId("cMSAuthBasic").disabled = false;
            dijit.byId("cMSConnTypeCSM").attr('checked', true);
            if (_useToken === false) {
                _setAuthType("basic");
            } else {
                _setAuthType("token");
            }
        } else if (type == "AGS") {
            _connType = "AGS";
            document.getElementById("emsArea1").style.display = "none";
            document.getElementById("emsArea2").style.display = "none";
            document.getElementById("emsArea3").style.display = "none";
            //dojo.byId('emsArea1').style("visibility", "none");
            dijit.byId("cMSConnTypeAGS").attr('checked', true);
            //disable all CSM stuff
            dojo.byId("cMSAuthToken").disabled = true;
            dojo.byId("cMSAuthBasic").disabled = true;
            dojo.byId("cToken").disabled = true;
            dojo.byId("msTokenId").disabled = true;
            dojo.byId("cTokenService").disabled = true;
        }
    };
    //Set Map Service Type
    var _setMapServiceType = function (type) {
        _defaultProtectedServiceType = type;
        if (type == "Tiled") {
            document.getElementById("visLayersArea").style.display = "none";
            document.getElementById("mapServiceArea").style.display = "none";
        } else {
            //Dynamic
            document.getElementById("visLayersArea").style.display = "block";
            document.getElementById("mapServiceArea").style.display = "block";
        }

    };
    //Set Image Type
    var _setImageType = function (type) {
        if (type == "PNG8") {
            dijit.byId("cImageTypePNG8").attr('checked', true);
        } else {
            dijit.byId("cImageTypePNG32").attr('checked', true);
        }
    };

    var _getMap = function () {
        return _map;
    };

    dojo.addOnLoad(_init);

    //public
    return {
        GetEntitlements: function () { _getEntitlements(); },
        UpdateEMSServiceParameters: function (sendToServer) { _updateEMSServiceParameters(sendToServer); },
        GetEntitlementsSource: function () { _getEntitlementsSource(); },
        OnSelectChange: function () { _onSelectChange(); },
        ReceiveServerData: function (arg, context) { _receiveServerData(arg, context); },
        SetAuthType: function (type) { _setAuthType(type); },
        SetConnType: function (conType) { _setConnType(conType); },
        SaveConfiguration: function (overwrite, name) { _saveConfiguration(overwrite, name); },
        SetMapServiceType: function (type) { _setMapServiceType(type); },
        Map: function () { return _map; },
        Hello: function () { _hello(); }
    };
};

//test export function
IHS.GIS.Mapping.EMS.Export = function (map) {
    var _map = map;
    var _click = function () {
        var scale = esri.geometry.getScale(_map); //_map.getScale();
        if (scale > 290000) {
            alert("Spatial Exports not allowed at this scale level");
            return;
        }

        var selectionToolbar = new esri.toolbars.Draw(_map);
        dojo.connect(selectionToolbar, "onDrawEnd", function (geometry) {
            selectionToolbar.deactivate();
            var symbol = new esri.symbol.SimpleFillSymbol(esri.symbol.SimpleFillSymbol.STYLE_SOLID, new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_DASHDOT, new dojo.Color([255, 0, 0]), 2), new dojo.Color([255, 255, 0, 0.25]));
            var graphic = new esri.Graphic(geometry, symbol);
            _map.graphics.add(graphic);
            _process();
        });

        selectionToolbar.activate(esri.toolbars.Draw.POLYGON);

    };
    var _process = function () {
        var mapExtent = _map.extent;
        //var geom = mapExtent;

        //var gp = new esri.tasks.Geoprocessor("http://tags.ihs.com/ArcGIS/rest/services/Enerdeq/EnerdeqSpatialExports/GPServer/Extract%20Data%20Task");
        var gp = new esri.tasks.Geoprocessor("http://v-vwc2temsapp07.ihsglobal.local/ArcGIS/rest/services/Enerdeq/EnerdeqSpatialExports/GPServer/Extract%20Data%20Task");
        gp.setOutSpatialReference({ wkid: 102100 }); //4326

        var clipLayers = [];
        clipLayers.push('ENERGY_US.WELL_SURFACE_ENERDEQ');

        if (clipLayers.length === 0 || _map.graphics.graphics.length === 0) {
            alert('Select layers to extract and area of interest');
            return;
        }

        var features = [];
        // THIS CODE NEEDS TO CHANGE...
        for (var g = 0; g < _map.graphics.graphics.length; g++) {
            if (_map.graphics.graphics[g].geometry.type === "polygon") {
                features.push(_map.graphics.graphics[g]);
            }
        }
        var featureSet = new esri.tasks.FeatureSet();
        featureSet.features = features;

        var params = { "Layers_to_Clip": clipLayers,
            "Area_of_Interest": featureSet,
            "Feature_Format": "File Geodatabase - GDB - .gdb",
            "Raster_Format": ""
        };

        var _getZipUrl = function (outputFile) {
            var theurl = outputFile.value.url;
            alert("URL: " + theurl);
            _map.graphics.clear();
        };

        var _completeCallback = function (jobInfo) {
            if (jobInfo.jobStatus !== "esriJobFailed") {
                gp.getResultData(jobInfo.jobId, "Output_Zip_File", _getZipUrl);
            }
        };

        var _statusCallback = function (jobInfo) {
            var status = jobInfo.jobStatus;
            if (status === "esriJobFailed") {
                for (var e = 0; e < jobInfo.messages.length; e++) {
                    alert(jobInfo.messages[e].description);
                }
            }
            else if (status === "esriJobSucceeded") {
                alert("job succeeded");
            }
        };

        gp.submitJob(params, _completeCallback, _statusCallback, function (error) {
            alert(error);
        });
    };


    return {
        ExportClick: function () { _click(); }
    };
};